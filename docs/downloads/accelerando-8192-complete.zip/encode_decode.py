"""Encode/decode arbitrary UTF-8 files with the permanent 8192-glyph mapping.
Usage: python encode_decode.py encode input.txt output.glyphs.txt
       python encode_decode.py decode output.glyphs.txt restored.txt
Encoding requires tiktoken; decoding uses only Python's standard library.
"""
import sys,json,base64
from pathlib import Path
root=Path(__file__).resolve().parent
cfg=json.loads((root/'tokenizer-8192.json').read_text())
raw={r['token_id']:base64.b64decode(r['token_bytes_base64']) for r in cfg['vocabulary']}
mode,src,dst=sys.argv[1:]
if mode=='encode':
 import tiktoken
 enc=tiktoken.Encoding(name=cfg['name'],pat_str=cfg['pat_str'],mergeable_ranks={b:i for i,b in raw.items()},special_tokens={})
 text=Path(src).read_bytes().decode('utf-8')
 Path(dst).write_bytes(''.join(chr(0xF0000+i) for i in enc.encode(text)).encode('utf-8'))
elif mode=='decode':
 text=Path(src).read_bytes().decode('utf-8')
 Path(dst).write_bytes(b''.join(raw[ord(c)-0xF0000] for c in text))
else:raise SystemExit('Mode must be encode or decode')
