from pathlib import Path
import json, base64
root = Path(__file__).resolve().parent
key = {int(r["glyph_id"]): base64.b64decode(r["token_bytes_base64"]) for r in json.loads((root / "token-key.json").read_text())}
lines = []
for line in (root / "glyph-transcript.txt").read_text().splitlines():
    if not line or line.startswith("["):
        lines.append(line)
    else:
        lines.append(b"".join(key[ord(c) - 0xF0000] for c in line).decode("utf-8"))
text = "\n".join(lines) + "\n"
assert text == (root / "lyrics-provided.txt").read_text()
print(text, end="")
